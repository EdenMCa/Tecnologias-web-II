from app.extensions import db

class UsuariosModel(db.Model):
    __tablename__ = 'usuarios' # Definir un nombre para la tabla
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    nombre_usuario = db.Column(db.String(50), nullable=False, unique=True)
    password = db.Column(db.String(255), nullable=False)

    def to_dict(self):
        return {
            'id': self.id,
            'nombre_usuario': self.nombre_usuario,
            'password': self.password
        }

#Relacion a la tabla de roles
    rol_id = db.Column(db.Integer, db.ForeignKey('roles.id'), nullable=False)
    rol = db.relationship('RolesModel', back_populates='usuarios')

class RolModel(db.Model):
    __tablename__ = 'roles'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    nombre_rol = db.Column(db.String(50), nullable=False, unique=True)

    # Relación inversa con UsuariosModel
    usuarios = db.relationship('UsuariosModel', back_populates='rol', lazy=True)