usuarios = [
    {'id': 1, 'nombre': 'Eden', 'correo' : 'casarrubiaeden@gmail.com', 'password' : 'eden123'},
    {'id': 2, 'nombre': 'Rosendo', 'correo' : 'mendozarosendo183@gmail.com', 'password' : 'rosendo123'},
]